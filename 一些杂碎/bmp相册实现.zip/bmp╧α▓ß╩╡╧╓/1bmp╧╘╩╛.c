#include "myhead.h"
/*
	封装bmp显示的函数
	
*/
int show_bmp(const char *bmppath)
{
	int bmpfd;
	int lcdfd;
	int i,x,y;
	//定义数组把整个图片的BGR数据存放起来
	char bmpbuf[800*480*3]; //char类型占1个字节
	//定义数组把转换得到的ARGB数据存放起来
	int lcdbuf[800*480]; //int占4字节
	int tempbuf[800*480]; 
	
	//打开bmp图片和液晶屏
	bmpfd=open(bmppath,O_RDWR);
	if(bmpfd==-1)
	{
		perror("打开图片失败了!\n");
		return -1;
	}
	
	lcdfd=open("/dev/fb0",O_RDWR);
	if(lcdfd==-1)
	{
		perror("打开lcd失败了!\n");
		return -1;
	}
	
	//最前面有54字节的头信息，从55字节开始才是真实的BGR数据
	//跳过最前面的54字节，从55个字节开始读取bmp图片的像素点颜色值
	lseek(bmpfd,54,SEEK_SET);
	read(bmpfd,bmpbuf,800*480*3);
	
	
	//把3个字节的BRG转换成4个字节的ARGB
	for(i=0; i<800*480; i++)
		lcdbuf[i]=0x00<<24|bmpbuf[3*i+2]<<16|bmpbuf[3*i+1]<<8|bmpbuf[3*i];
	
	//把图片正转过来
		for(x=0; x<800; x++)
	{
		for(y=0; y<480; y++)
			tempbuf[(479-y)*800+x]=lcdbuf[y*800+x];
	}
	//把刚才转换得到的ARGB数据写入到液晶屏
	write(lcdfd,tempbuf,800*480*4);
	
	//关闭
	close(bmpfd);
	close(lcdfd);
	return 0;
}