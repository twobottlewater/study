#ifndef _MYHEAD_H
#define _MYHEAD_H
//把所有常用的头文件全部包含
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <stdlib.h>
#include <strings.h>
#include <stdbool.h>
#include <unistd.h>
#include <errno.h>  //跟perror有关
#include <linux/input.h> //跟输入子系统模型有关
#include <dirent.h>


#endif

